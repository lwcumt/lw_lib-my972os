#ifndef _GTP_TOUCH_H
#define _GTP_TOUCH_H

#include "main.h"




extern void Gtp_Touch_Scan(void);



#endif

