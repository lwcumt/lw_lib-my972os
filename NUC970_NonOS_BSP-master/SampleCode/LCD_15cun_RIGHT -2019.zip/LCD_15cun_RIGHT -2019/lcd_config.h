#ifndef _LCD_CONFIG_H
#define _LCD_CONFIG_H
#include "main.h"
extern pInt8U Lcd_Set_DisBufAdd(Int32U bufferadder);

#endif
