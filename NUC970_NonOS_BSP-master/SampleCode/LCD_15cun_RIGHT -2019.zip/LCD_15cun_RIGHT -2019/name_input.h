

#ifndef _NAME_INPUT_H
#define _NAME_INPUT_H

#include"pinyin.h"

#define PRONAME_SIZE	20//25


#define KEY_UP		0
#define KEY_DOWN	1
#define KEY_LEFT	2
#define KEY_RIGHT	3






#endif